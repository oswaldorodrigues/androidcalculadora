package com.example.oswaldo.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;




public class MainActivity extends AppCompatActivity {
    //botoes
    private Button buttonLimpar;
    private Button buttonSomar;
    private Button buttonSubtrair;
    private Button buttonMultiplicar;
    private Button buttonDividir;

    //edittext
    private EditText editTex;
    private EditText editTex1;
    //textrview
    private TextView textView;
    //variaveis utilizada nas operações
    private double resultado;
    private int a;
    private  int b;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //botoes
        buttonLimpar = (Button)findViewById(R.id.buttonLimpar);
        buttonSomar = (Button)findViewById(R.id.buttonSomar);
        buttonSubtrair = (Button)findViewById(R.id.buttonSubtrair);
        buttonMultiplicar = (Button)findViewById(R.id.buttonMultiplicar);
        buttonDividir = (Button)findViewById(R.id.buttonDividir);
        //edittext
        editTex = (EditText) findViewById(R.id.editText);
        editTex1 = (EditText) findViewById(R.id.editText2);
        //textview
        textView = (TextView) findViewById(R.id.textView);


        //botao limpar
        buttonLimpar.setOnClickListener (new View.OnClickListener(){
            @Override
            public void onClick(View v){

               editTex.setText("");
               editTex1.setText("");
               textView.setText("");
            }
        });

    }
    public void somar (View view){
        a= Integer.parseInt(editTex.getText().toString());
        b= Integer.parseInt(editTex1.getText().toString());
        resultado= a+b;
        textView.setText("o resultado é: "+resultado);
    }
    public void subtrair (View view){
        a= Integer.parseInt(editTex.getText().toString());
        b= Integer.parseInt(editTex1.getText().toString());
        resultado= a-b;
        textView.setText("o resultado é: "+resultado);
    }
    public void multiplicar (View view){
        a= Integer.parseInt(editTex.getText().toString());
        b= Integer.parseInt(editTex1.getText().toString());
        resultado= a*b;
        textView.setText("o resultado é: "+resultado);
    }
    public void dividir (View view){
        a= Integer.parseInt(editTex.getText().toString());
        b= Integer.parseInt(editTex1.getText().toString());
        resultado= a/b;
        textView.setText("o resultado é: "+resultado);
    }
}
